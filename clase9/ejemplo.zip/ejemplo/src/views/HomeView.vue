<script>
import {IonPage} from '@ionic/vue'
export default {
  components: {IonPage}
}
</script>

<template>
  <ion-page>
    <h2>Home</h2>
  </ion-page>
</template>

<style>
</style>
